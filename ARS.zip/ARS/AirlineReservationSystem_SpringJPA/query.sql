select * from FlightInformation;
select * from BookingInformation;
delete from BookingInformation;
select * from CustomerInformation;
drop table AIRPORT cascade constraint;
select * from AIRPORT;

insert into AIRPORT values('PNQ','Maharashtra','Pune International Airport','Pune',411002);
insert into AIRPORT values('CCU','West Bengal','Nethaji Subashchandra Bose Airport','Calcutta',711002);
insert into AIRPORT values('BLR','Karnataka','Bangalore Airport','Bangalore',411003);
insert into AIRPORT values('MAA','Tamil Nadu','Chennai Airport','Chennai',711003);

insert into AIRPORT values('HYD','Andhra Pradesh','Hyderabad Airport','Hyderabad',411004);
insert into AIRPORT values('DEL','New Delhi','New Delhi Airport Airport','New Delhi',711005);
insert into AIRPORT values('BOM','Maharashtra','Mumbai Airport','Mumbai',411006);
insert into AIRPORT values('GUJ','Gujrat','Gujrat Airport','Gujrat',711072);


delete from FlightInformation;

INSERT INTO FlightInformation VALUES(1,'Jet Airways','PNQ','Pune',to_date('05/01/2018','dd/MM/yyyy'),'17:00',9000,50,'CCU','Calcutta',to_date('05/01/2018','dd/MM/yyyy'),'15:00',6000,50,'1001');
INSERT INTO FlightInformation VALUES(2,'Vistara','BLR','Bangalore',to_date('05/01/2018','dd/MM/yyyy'),'18:00',8000,50,'DEL','New Delhi',to_date('05/01/2018','dd/MM/yyyy'),'16:00',5000,50,'1002');
INSERT INTO FlightInformation VALUES(3,'Air India','MAA','Chennai',to_date('06/01/2018','dd/MM/yyyy'),'19:00',7000,50,'BOM','Mumbai',to_date('06/01/2018','dd/MM/yyyy'),'17:00',4000,50,'1003');
INSERT INTO FlightInformation VALUES(4,'Spice Jet','HYD','Hyderabad',to_date('06/01/2018','dd/MM/yyyy'),'20:00',6000,50,'GUJ','Gujrat',to_date('06/01/2018','dd/MM/yyyy'),'18:00',3000,50,'1004');

INSERT INTO FlightInformation VALUES(5,'Jet Airways','CCU','Calcutta',to_date('05/01/2018','dd/MM/yyyy'),'17:00',9000,50,'PNQ','Pune',to_date('05/01/2018','dd/MM/yyyy'),'15:00',6000,50,'1005');
INSERT INTO FlightInformation VALUES(6,'Vistara','DEL','New Delhi',to_date('05/01/2018','dd/MM/yyyy'),'18:00',8000,50,'BLR','Bangalore',to_date('05/01/2018','dd/MM/yyyy'),'16:00',5000,50,'1006');
INSERT INTO FlightInformation VALUES(7,'Air India','BOM','Mumbai',to_date('06/01/2018','dd/MM/yyyy'),'19:00',7000,50,'MAA','Chennai',to_date('06/01/2018','dd/MM/yyyy'),'17:00',4000,50,'1007');
INSERT INTO FlightInformation VALUES(8,'Spice Jet','GUJ','Gujrat',to_date('06/01/2018','dd/MM/yyyy'),'20:00',6000,50,'HYD','Hyderabad',to_date('06/01/2018','dd/MM/yyyy'),'18:00',3000,50,'1008');

INSERT INTO FlightInformation VALUES(9,'Jet Airways','PNQ','Pune',to_date('06/01/2018','dd/MM/yyyy'),'17:00',9000,50,'CCU','Calcutta',to_date('06/01/2018','dd/MM/yyyy'),'15:00',6000,50,'1009');
INSERT INTO FlightInformation VALUES(10,'Vistara','BLR','Bangalore',to_date('07/01/2018','dd/MM/yyyy'),'18:00',8000,50,'DEL','New Delhi',to_date('07/01/2018','dd/MM/yyyy'),'16:00',5000,50,'1010');
INSERT INTO FlightInformation VALUES(11,'Air India','MAA','Chennai',to_date('06/01/2018','dd/MM/yyyy'),'19:00',7000,50,'BOM','Mumbai',to_date('06/01/2018','dd/MM/yyyy'),'17:00',4000,50,'1011');
INSERT INTO FlightInformation VALUES(12,'Spice Jet','HYD','Hyderabad',to_date('07/01/2018','dd/MM/yyyy'),'20:00',6000,50,'GUJ','Gujrat',to_date('07/01/2018','dd/MM/yyyy'),'18:00',3000,50,'1012');

INSERT INTO FlightInformation VALUES(13,'Jet Airways','CCU','Calcutta',to_date('06/01/2018','dd/MM/yyyy'),'17:00',9000,50,'PNQ','Pune',to_date('06/01/2018','dd/MM/yyyy'),'15:00',6000,50,'1013');
INSERT INTO FlightInformation VALUES(14,'Vistara','DEL','New Delhi',to_date('06/01/2018','dd/MM/yyyy'),'18:00',8000,50,'BLR','Bangalore',to_date('06/01/2018','dd/MM/yyyy'),'16:00',5000,50,'1014');
INSERT INTO FlightInformation VALUES(15,'Air India','BOM','Mumbai',to_date('07/01/2018','dd/MM/yyyy'),'19:00',7000,50,'MAA','Chennai',to_date('07/01/2018','dd/MM/yyyy'),'17:00',4000,50,'1015');
INSERT INTO FlightInformation VALUES(16,'Spice Jet','GUJ','Gujrat',to_date('07/01/2018','dd/MM/yyyy'),'20:00',6000,50,'HYD','Hyderabad',to_date('07/01/2018','dd/MM/yyyy'),'18:00',3000,50,'1016');

INSERT INTO FlightInformation VALUES(17,'Capgemini Airlines','PNQ','Pune',to_date('05/01/2018','dd/MM/yyyy'),'20:00',100,50,'DEL','New Delhi',to_date('05/01/2018','dd/MM/yyyy'),'22:00',5000,50,'1017');


delete from FlightInformation where flightid = 1;

desc FlightInformation;
