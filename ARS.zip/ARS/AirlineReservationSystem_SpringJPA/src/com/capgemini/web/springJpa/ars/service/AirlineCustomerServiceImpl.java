package com.capgemini.web.springJpa.ars.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.web.springJpa.ars.dao.AirlineCustomerDAO;
import com.capgemini.web.springJpa.ars.entities.Airport;
import com.capgemini.web.springJpa.ars.entities.BookingInformation;
import com.capgemini.web.springJpa.ars.entities.CustomerInformation;
import com.capgemini.web.springJpa.ars.entities.FlightInformation;
import com.capgemini.web.springJpa.ars.entities.LoginBean;
import com.capgemini.web.springJpa.ars.entities.SearchFlight;
import com.capgemini.web.springJpa.ars.exception.AirlineReservationSystemException;

@Service
@Transactional
public class AirlineCustomerServiceImpl implements AirlineCustomerService 
{
	@Autowired
	private AirlineCustomerDAO airlineCustomerDAO;

	public AirlineCustomerDAO getAirlineCustomerDAO() {
		return airlineCustomerDAO;
	}

	public void setAirlineCustomerDAO(AirlineCustomerDAO airlineCustomerDAO) {
		this.airlineCustomerDAO = airlineCustomerDAO;
	}

	public AirlineCustomerServiceImpl() {
		
	}

	
	/************************************************************************************
	* Module Name       : signUpCustomer(customerInformation)
	* Input Parameters  : customerInformation
	* Return Type         : void
	* Author                 : Eniya and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : SIGNUP FORM FOR CUSTOMER
	 ************************************************************************************/
	
	@Override
	public void signUpCustomer(CustomerInformation customerInformation) throws AirlineReservationSystemException 
	{
		airlineCustomerDAO.signUpCustomer(customerInformation);

	}

	/************************************************************************************
	* Module Name       : getUsers()
	* Input Parameters  : -
	* Return Type         : List<CustomerInformation>
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : Retriving User Information
	 ************************************************************************************/
	
	@Override
	public List<CustomerInformation> getUsers() throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.getUsers();
	}

	
	/************************************************************************************
	* Module Name       : addCustomerBooking(bookingInformation)
	* Input Parameters  : bookingInformation
	* Return Type         : int
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : Add Customer Details in Booking table
	 ************************************************************************************/
	
	@Override
	public int addCustomerBooking(BookingInformation bookingInformation)
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.addCustomerBooking(bookingInformation);
	}

	/************************************************************************************
	* Module Name       : viewCustomerBooking( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : BookingInformation
	* Author                 : Eniya Murali and Shruthi
	* Creation Date       : 23-Dec-2017
	*  Description          : View Customer details
	 ************************************************************************************/
	
	@Override
	public BookingInformation viewCustomerBooking(int bookingId,String username)
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.viewCustomerBooking(bookingId,username);
	}

	/************************************************************************************
	* Module Name       : viewFlightDetails(searchFlight)
	* Input Parameters  : searchFlight
	* Return Type         : List<FlightInformation>
	* Author                 : Eniya Murali and Shruthi
	* Creation Date       : 23-Dec-2017
	*  Description          : View Flight details
	 ************************************************************************************/
	
	@Override
	public List<FlightInformation> viewFlightDetails(SearchFlight searchFlight)
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.viewFlightDetails(searchFlight);
	}

	
	/************************************************************************************
	* Module Name       : updateCustomerBooking( bookingInformation)
	* Input Parameters  : bookingInformation
	* Return Type         : void
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : Update Customer details
	 ************************************************************************************/
	
	@Override
	public void updateCustomerBooking(BookingInformation bookingInformation) throws AirlineReservationSystemException
	{
	
		airlineCustomerDAO.updateCustomerBooking(bookingInformation);
	}

	
	/************************************************************************************
	* Module Name       : cancelCustomerBooking( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : BookingInformation
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : Cancel Flight Booking Details
	 ************************************************************************************/
	
	@Override
	public BookingInformation cancelCustomerBooking(int bookingId,String username)
			throws AirlineReservationSystemException {
	
		return airlineCustomerDAO.cancelCustomerBooking(bookingId,username);
	}

	/************************************************************************************
	* Module Name       : getAllAirports()
	* Input Parameters  : -
	* Return Type         : List<Airport>
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : get all airport details
	 ************************************************************************************/
	
	@Override
	public List<Airport> getAllAirports()
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.getAllAirports();
	}

	
	/************************************************************************************
	* Module Name       : viewSingleFlightDetail( id)
	* Input Parameters  : id
	* Return Type         : FlightInformation
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : View single flight Details
	 ************************************************************************************/
	
	@Override
	public FlightInformation viewSingleFlightDetail(int id) throws AirlineReservationSystemException 
	{
		
		return airlineCustomerDAO.viewSingleFlightDetail(id);
	}

	
	/************************************************************************************
	* Module Name       : validateLogin( login)
	* Input Parameters  : login
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : To Validate Login Credentials
	 ************************************************************************************/
	
	@Override
	public boolean validateLogin(LoginBean login)
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.validateLogin(login);
	}

	
	/************************************************************************************
	* Module Name       : searchCustomerExist( userName)
	* Input Parameters  : userName
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : To validate customer is there or not in database
	 ************************************************************************************/
	
	@Override
	public boolean searchCustomerExist(String userName)
			throws AirlineReservationSystemException {
		return airlineCustomerDAO.searchCustomerExist(userName);
	}
	/************************************************************************************
	* Module Name       : searchBookingExist( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 23-Dec-2017
	*  Description          : View Flight Booking Details
	 ************************************************************************************/
	
	@Override
	public boolean searchBookingExist(int bookingId, String username)
			throws AirlineReservationSystemException {
		
		return airlineCustomerDAO.searchBookingExist(bookingId,username);
	}
}
