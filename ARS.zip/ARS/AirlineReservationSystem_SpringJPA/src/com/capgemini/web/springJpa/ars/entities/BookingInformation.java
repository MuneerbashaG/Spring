package com.capgemini.web.springJpa.ars.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

//Spring Bean
@Entity
public class BookingInformation 
{
	@Id
	@SequenceGenerator(name="seq",sequenceName="booking_id_seq",allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private int bookingId;
	
	@Min(value=1,message="Number of Passangers Should not be empty")
	@Max(value=40,message="Maximum number of seats is 40.So book according to that count")
	private int noOfPassangers;
	
	@NotEmpty(message="Class type should not be empty")
	private String classType;
	
	private String airline;
	
	private String departureCity;
	
	private String arrivalCity;
	
	@NotNull(message="Departure Date field Can not be empty")
	private Date departureDate;
	
	private Date arrivalDate;
	
	private String departureTime;
	
	private String arrivalTime;
	
	private String seatNumber;
	
	private double totalFare;
	
	private int flightId;
	
	private String flightNumber;
	
	@NotEmpty(message= "Name cannot be empty")
	@Pattern(regexp="[A-Za-z ]+",message="Please enter alphabets.")
	private String customerName;
	
	@NotEmpty(message = "Email should not be empty")
	@Pattern(regexp = "[a-z0-9]+@[a-z]+.[a-z]{2,3}", message = "Give a valid email address. Example- abc@xyz.com")
	private String customerEmail;
	
	@NotEmpty(message = "Phone number should not be empty")
	@Pattern(regexp = "[789]{1}[0-9]{9}", message = "Please provide a valid Phone Number. It should consist of 10 digits.")
	private String customerPhoneNumber;
	
	@NotEmpty(message = "Card number cannot be empty")
	@Pattern(regexp = "[0-9]{16}", message = "Please provide a valid Card Number. It should consist of 16 digits.")
	private String creditCardNumber;

	private String userName;
	
	public BookingInformation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingInformation(int bookingId, int noOfPassangers,
			String classType, String airline, String departureCity,
			String arrivalCity, Date departureDate, Date arrivalDate,
			String departureTime, String arrivalTime, String seatNumber,
			double totalFare, int flightId, String flightNumber,
			String customerName, String customerEmail,
			String customerPhoneNumber, String creditCardNumber, String userName) {
		super();
		this.bookingId = bookingId;
		this.noOfPassangers = noOfPassangers;
		this.classType = classType;
		this.airline = airline;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.seatNumber = seatNumber;
		this.totalFare = totalFare;
		this.flightId = flightId;
		this.flightNumber = flightNumber;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
		this.creditCardNumber = creditCardNumber;
		this.userName = userName;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getNoOfPassangers() {
		return noOfPassangers;
	}

	public void setNoOfPassangers(int noOfPassangers) {
		this.noOfPassangers = noOfPassangers;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDepartureCity() {
		return departureCity;
	}

	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}

	public String getArrivalCity() {
		return arrivalCity;
	}

	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "BookingInformation [bookingId=" + bookingId
				+ ", noOfPassangers=" + noOfPassangers + ", classType="
				+ classType + ", airline=" + airline + ", departureCity="
				+ departureCity + ", arrivalCity=" + arrivalCity
				+ ", departureDate=" + departureDate + ", arrivalDate="
				+ arrivalDate + ", departureTime=" + departureTime
				+ ", arrivalTime=" + arrivalTime + ", seatNumber=" + seatNumber
				+ ", totalFare=" + totalFare + ", flightId=" + flightId
				+ ", flightNumber=" + flightNumber + ", customerName="
				+ customerName + ", customerEmail=" + customerEmail
				+ ", customerPhoneNumber=" + customerPhoneNumber
				+ ", creditCardNumber=" + creditCardNumber + ", userName="
				+ userName + "]";
	}

	

	
}
