package com.capgemini.web.springJpa.ars.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

//Spring Bean
@Entity
public class CustomerInformation {
	@Id
	@NotEmpty(message = "Username Should not be empty")
	@Pattern(regexp = "[A-Za-z]+[0-9]*", message="Invalid Username. It should consist of Alphabets followed by number.")
	private String userName;

	@NotEmpty(message = "Name should not be empty")
	@Pattern(regexp = "[A-Za-z ]+", message="Name should only consist of Alphabets")
	private String customerName;

	@NotEmpty(message = "Phone number should not be empty")
	@Pattern(regexp = "[789]{1}[0-9]{9}", message = "Please provide a valid Phone Number. It should consist of 10 digits in correct form.")
	private String customerPhone;

	@NotEmpty(message = "Email should not be empty")
	@Pattern(regexp = "[a-z0-9]+@[a-z]+.[a-z]{2,3}", message = "Give a valid email address. Example- abc@xyz.com")
	private String customerEmail;

	@NotEmpty(message = "Address should not be empty")
	private String residentialAddress;

	@NotEmpty(message = "Please enter the Password")
	private String password;
	
	@NotEmpty(message = "Please enter the Password")
	@Transient
	private String confirmPassword;

	public CustomerInformation(String userName, String customerName,
			String customerPhone, String customerEmail,
			String residentialAddress, String password, String confirmPassword) {
		super();
		this.userName = userName;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerEmail = customerEmail;
		this.residentialAddress = residentialAddress;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}

	public CustomerInformation() {
		super();
	}

	@Override
	public String toString() {
		return "CustomerInformation [userName=" + userName + ", customerName="
				+ customerName + ", customerPhone=" + customerPhone
				+ ", customerEmail=" + customerEmail + ", residentialAddress="
				+ residentialAddress + ", password=" + password
				+ ", confirmPassword=" + confirmPassword + "]";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}