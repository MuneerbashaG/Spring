 package com.capgemini.web.springJpa.ars.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.web.springJpa.ars.entities.Airport;
import com.capgemini.web.springJpa.ars.entities.BookingInformation;
import com.capgemini.web.springJpa.ars.entities.CustomerInformation;
import com.capgemini.web.springJpa.ars.entities.FlightInformation;
import com.capgemini.web.springJpa.ars.entities.LoginBean;
import com.capgemini.web.springJpa.ars.entities.SearchFlight;
import com.capgemini.web.springJpa.ars.exception.AirlineReservationSystemException;

@Repository
public class AirlineCustomerDAOImpl implements AirlineCustomerDAO {
	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public AirlineCustomerDAOImpl() {
		
	}
	
	/************************************************************************************
	* Module Name       : signUpCustomer(customerInformation)
	* Input Parameters  : customerInformation
	* Return Type         : void
	* Author                 : Eniya and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : SIGNUP FORM FOR CUSTOMER
	 ************************************************************************************/
	@Override
	public void signUpCustomer(CustomerInformation customerInformation) throws AirlineReservationSystemException {
		try {
			entityManager.persist(customerInformation);
			entityManager.flush();

		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

	}
	
	/************************************************************************************
	* Module Name       : getUsers()
	* Input Parameters  : -
	* Return Type         : List<CustomerInformation>
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : Retriving User Information
	 ************************************************************************************/
	@Override
	public List<CustomerInformation> getUsers() throws AirlineReservationSystemException {
		List<CustomerInformation> listOfUsers = null;

		try {
			String query = "select users from Users users";
			TypedQuery<CustomerInformation> tQuery = entityManager.createQuery(query,CustomerInformation.class);
			listOfUsers = tQuery.getResultList();

		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

		return listOfUsers;
	}

	
	/************************************************************************************
	* Module Name       : addCustomerBooking(bookingInformation)
	* Input Parameters  : bookingInformation
	* Return Type         : int
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : Add Customer Details in Booking table
	 ************************************************************************************/
	@Override
	public int addCustomerBooking(BookingInformation bookingInformation)
			throws AirlineReservationSystemException {
		int bookingId = 0;

		try {
			FlightInformation flightInformation = entityManager.find(
					FlightInformation.class, bookingInformation.getFlightId());

			if (flightInformation == null)
				throw new AirlineReservationSystemException(
						"No flight with flight number:"
								+ bookingInformation.getFlightNumber());

			if (bookingInformation.getClassType().equalsIgnoreCase(
					"First Class")) {
				if (flightInformation.getFirstSeats() < bookingInformation
						.getNoOfPassangers()) {
					throw new AirlineReservationSystemException(
							"Required number of seats not available in :"
									+ bookingInformation.getClassType());
				} else {
					String updateFirstSeats = "update FlightInformation flightInformation set flightInformation.firstSeats=:fs where flightInformation.flightId=:fId";

					Query query = entityManager.createQuery(updateFirstSeats);

					query.setParameter("fs", flightInformation.getFirstSeats()
							- bookingInformation.getNoOfPassangers());
					query.setParameter("fId", bookingInformation.getFlightId());

					query.executeUpdate();
				}
			}

			else {
				if (flightInformation.getBussSeats() < bookingInformation
						.getNoOfPassangers()) {
					throw new AirlineReservationSystemException(
							"Required number of seats not available in :"
									+ bookingInformation.getClassType());
				} else {
					String updateFirstSeats = "update FlightInformation flightInformation set flightInformation.bussSeats=:bs where flightInformation.flightId=:fId";

					Query query = entityManager.createQuery(updateFirstSeats);

					query.setParameter("bs", flightInformation.getBussSeats()
							- bookingInformation.getNoOfPassangers());
					query.setParameter("fId", bookingInformation.getFlightId());

					query.executeUpdate();

				}
			}

			entityManager.persist(bookingInformation);

			bookingId = bookingInformation.getBookingId();

			entityManager.flush();

		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

		return bookingId;
	}

	
	/************************************************************************************
	* Module Name       : viewCustomerBooking( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : BookingInformation
	* Author                 : Eniya Murali and Shruthi
	* Creation Date       : 22-Dec-2017
	*  Description          : View Customer details
	 ************************************************************************************/
	@Override
	public BookingInformation viewCustomerBooking(int bookingId,String username)
			throws AirlineReservationSystemException {
		BookingInformation bookingInformation = null;

		try {
			
			String query="Select bookingInformation from BookingInformation bookingInformation where bookingInformation.userName=:uname and bookingInformation.bookingId=:bid ";
			
			TypedQuery<BookingInformation> tQuery=entityManager.createQuery(query,BookingInformation.class);
			tQuery.setParameter("uname", username);
			tQuery.setParameter("bid", bookingId);
			
			bookingInformation=tQuery.getSingleResult();
			
			entityManager.flush();

			if (bookingInformation == null)
				throw new AirlineReservationSystemException(
						"There are no customers");

		}
		catch(NoResultException e)
		{
			throw new AirlineReservationSystemException("Invalid Booking Id.");
		}
		
		catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

		return bookingInformation;
	}

	
	/************************************************************************************
	* Module Name       : viewFlightDetails(searchFlight)
	* Input Parameters  : searchFlight
	* Return Type         : List<FlightInformation>
	* Author                 : Eniya Murali and Shruthi
	* Creation Date       : 22-Dec-2017
	*  Description          : View Flight details
	 ************************************************************************************/
	@Override
	public List<FlightInformation> viewFlightDetails(SearchFlight searchFlight)
			throws AirlineReservationSystemException {
		List<FlightInformation> flightList = null;

		try {
			String query = "select flightInformation from FlightInformation flightInformation where flightInformation.departureCity=:depCity and flightInformation.arrivalCity=:arrCity and flightInformation.departureDate=:depDate";
			TypedQuery<FlightInformation> tQuery = entityManager.createQuery(
					query, FlightInformation.class);
			tQuery.setParameter("depCity", searchFlight.getDepartureCity());
			tQuery.setParameter("arrCity", searchFlight.getArrivalCity());
			tQuery.setParameter("depDate", searchFlight.getDepartureDate());
			flightList = tQuery.getResultList();
			System.out.println(flightList);
		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

		return flightList;
	}

	
	/************************************************************************************
	* Module Name       : updateCustomerBooking( bookingInformation)
	* Input Parameters  : bookingInformation
	* Return Type         : void
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : Update Customer details
	 ************************************************************************************/
	@Override
	public void updateCustomerBooking(BookingInformation bookingInformation)
			throws AirlineReservationSystemException {
		try {
			entityManager.merge(bookingInformation);
			entityManager.flush();
		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

	}

	
	/************************************************************************************
	* Module Name       : searchBookingExist( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : View Flight Booking Details
	 ************************************************************************************/
	@Override
	public boolean searchBookingExist(int bookingId,String username)
			throws AirlineReservationSystemException {
		 
		try {
			
			String query="Select bookingInformation.bookingId from BookingInformation bookingInformation where bookingInformation.userName=:uname ";
			
			TypedQuery<Integer> tQuery=entityManager.createQuery(query,Integer.class);
			tQuery.setParameter("uname", username);
			List<Integer> bookingIds=tQuery.getResultList();
			for(int bId:bookingIds)
			{
				if(bookingId==bId)
					return true;
			}
								
			return false;
		
		} catch (Exception e) 
		{
			throw new AirlineReservationSystemException(e);
			
		}
	}
	
	
	/************************************************************************************
	* Module Name       : cancelCustomerBooking( bookingId, username)
	* Input Parameters  : bookingId, username
	* Return Type         : BookingInformation
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : Cancel Flight Booking Details
	 ************************************************************************************/
	@Override
	public BookingInformation cancelCustomerBooking(int bookingId,String username)
			throws AirlineReservationSystemException {
		BookingInformation bookingInformation = null;

		try {
			bookingInformation=viewCustomerBooking(bookingId,username);
			
			FlightInformation flightInformation = entityManager.find(
					FlightInformation.class, bookingInformation.getFlightId());

			if (flightInformation == null)
				throw new AirlineReservationSystemException(
						"No flight with flight number:"
								+ bookingInformation.getFlightNumber());

			if (bookingInformation.getClassType().equalsIgnoreCase(
					"First Class")) {

				String updateFirstSeats = "update FlightInformation flightInformation set flightInformation.firstSeats=:fs where flightInformation.flightId=:fId";

				Query query = entityManager.createQuery(updateFirstSeats);

				query.setParameter("fs", flightInformation.getFirstSeats()
						+ bookingInformation.getNoOfPassangers());
				query.setParameter("fId", bookingInformation.getFlightId());

				query.executeUpdate();

			}

			else {

				String updateFirstSeats = "update FlightInformation flightInformation set flightInformation.bussSeats=:bs where flightInformation.flightId=:fId";

				Query query = entityManager.createQuery(updateFirstSeats);

				query.setParameter("bs", flightInformation.getBussSeats()
						+ bookingInformation.getNoOfPassangers());
				query.setParameter("fId", bookingInformation.getFlightId());

				query.executeUpdate();

			}

			entityManager.remove(bookingInformation);

		} catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}

		return bookingInformation;
	}

	
	/************************************************************************************
	* Module Name       : getAllAirports()
	* Input Parameters  : -
	* Return Type         : List<Airport>
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : get all airport details
	 ************************************************************************************/
	@Override
	public List<Airport> getAllAirports() throws AirlineReservationSystemException {
		List<Airport> airportList = null;
		try
		{
			String query = "select airport from Airport airport";
			TypedQuery<Airport> tQuery = entityManager.createQuery(query,Airport.class);
			airportList = tQuery.getResultList();
		}
		catch (Exception e) {
			throw new AirlineReservationSystemException(e);
		}
		
		return airportList;
	}

	
	/************************************************************************************
	* Module Name       : viewSingleFlightDetail( id)
	* Input Parameters  : id
	* Return Type         : FlightInformation
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : View single flight Details
	 ************************************************************************************/
	@Override
	public FlightInformation viewSingleFlightDetail(int id) throws AirlineReservationSystemException 
	{
		FlightInformation flightInfo=null;
		flightInfo=entityManager.find(FlightInformation.class, id);
		return flightInfo;
	}

	
	/************************************************************************************
	* Module Name       : validateLogin( login)
	* Input Parameters  : login
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : To Validate Login Credentials
	 ************************************************************************************/
	@Override
	public boolean validateLogin(LoginBean login) throws AirlineReservationSystemException {
		

		try {

			String query="Select customer.password from CustomerInformation customer";
			TypedQuery<String> tQuery=entityManager.createQuery(query,String.class);
			List<String> passwords=tQuery.getResultList();
			for(String pwd:passwords)
			{
				if(login.getPassword().equals(pwd))
					return true;
			}
			return false;

		} catch (Exception e) 
		{
			throw new AirlineReservationSystemException(e);

		}
	}

	
	/************************************************************************************
	* Module Name       : searchCustomerExist( userName)
	* Input Parameters  : userName
	* Return Type         : boolean
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 22-Dec-2017
	*  Description          : To validate customer is there or not in database
	 ************************************************************************************/
	@Override
	public boolean searchCustomerExist(String userName)
			throws AirlineReservationSystemException {
		 
		try {
			
			String query="Select customer.userName from CustomerInformation customer";
			TypedQuery<String> tQuery=entityManager.createQuery(query,String.class);
			List<String> usrnames=tQuery.getResultList();
			for(String user:usrnames)
			{
				if(userName.equals(user))
					return true;
			}
								
			return false;
		
		} catch (Exception e) 
		{
			throw new AirlineReservationSystemException(e);
			
		}
	}
}
