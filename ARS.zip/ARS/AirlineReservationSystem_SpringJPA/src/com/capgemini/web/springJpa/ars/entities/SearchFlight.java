package com.capgemini.web.springJpa.ars.entities;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class SearchFlight {
	
	@NotEmpty(message="Please select the Departure City")
	private String departureCity;
	
	@NotEmpty(message="Please select the Destination")
	private String arrivalCity;
	
	@NotNull(message="Select the date")
	private Date departureDate;
	public SearchFlight() {
		super();
	}
	public SearchFlight(String departureCity, String arrivalCity,
			Date departureDate) {
		super();
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	@Override
	public String toString() {
		return "SearchFlight [departureCity=" + departureCity
				+ ", arrivalCity=" + arrivalCity + ", departureDate="
				+ departureDate + "]";
	}
	
}
