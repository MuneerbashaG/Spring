package com.capgemini.web.springJpa.ars.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FlightInformation {
	@Id
	private int flightId;
	private String flightNumber;
	private String airline;
	private String departureCity;
	private String arrivalCity;
	private Date departureDate;
	private Date arrivalDate;
	private String departureTime;
	private String arrivalTime;
	private int firstSeats;
	private double firstSeatFare;
	private int bussSeats;
	private double bussSeatFare;
	private String arrivalAirportAbbrevation;
	private String departureAirportAbbrevation;
	public FlightInformation(int flightId, String flightNumber, String airline,
			String departureCity, String arrivalCity, Date departureDate,
			Date arrivalDate, String departureTime, String arrivalTime,
			int firstSeats, double firstSeatFare, int bussSeats,
			double bussSeatFare, String arrivalAirportAbbrevation,
			String departureAirportAbbrevation) {
		super();
		this.flightId = flightId;
		this.flightNumber = flightNumber;
		this.airline = airline;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.firstSeats = firstSeats;
		this.firstSeatFare = firstSeatFare;
		this.bussSeats = bussSeats;
		this.bussSeatFare = bussSeatFare;
		this.arrivalAirportAbbrevation = arrivalAirportAbbrevation;
		this.departureAirportAbbrevation = departureAirportAbbrevation;
	}
	public FlightInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Date getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public double getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public double getBussSeatFare() {
		return bussSeatFare;
	}
	public void setBussSeatFare(double bussSeatFare) {
		this.bussSeatFare = bussSeatFare;
	}
	public String getArrivalAirportAbbrevation() {
		return arrivalAirportAbbrevation;
	}
	public void setArrivalAirportAbbrevation(String arrivalAirportAbbrevation) {
		this.arrivalAirportAbbrevation = arrivalAirportAbbrevation;
	}
	public String getDepartureAirportAbbrevation() {
		return departureAirportAbbrevation;
	}
	public void setDepartureAirportAbbrevation(String departureAirportAbbrevation) {
		this.departureAirportAbbrevation = departureAirportAbbrevation;
	}
	@Override
	public String toString() {
		return "FlightInformation [flightId=" + flightId + ", flightNumber="
				+ flightNumber + ", airline=" + airline + ", departureCity="
				+ departureCity + ", arrivalCity=" + arrivalCity
				+ ", departureDate=" + departureDate + ", arrivalDate="
				+ arrivalDate + ", departureTime=" + departureTime
				+ ", arrivalTime=" + arrivalTime + ", firstSeats=" + firstSeats
				+ ", firstSeatFare=" + firstSeatFare + ", bussSeats="
				+ bussSeats + ", bussSeatFare=" + bussSeatFare
				+ ", arrivalAirportAbbrevation=" + arrivalAirportAbbrevation
				+ ", departureAirportAbbrevation="
				+ departureAirportAbbrevation + "]";
	}

	

}
