package com.capgemini.web.springJpa.ars.exception;

@SuppressWarnings("serial")
public class AirlineReservationSystemException extends Exception {

	public AirlineReservationSystemException() {
	}

	public AirlineReservationSystemException(String message) {
		super(message);
	}

	public AirlineReservationSystemException(Throwable cause) {
		super(cause);
	}

	public AirlineReservationSystemException(String message, Throwable cause) {
		super(message, cause);
	}

	public AirlineReservationSystemException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
