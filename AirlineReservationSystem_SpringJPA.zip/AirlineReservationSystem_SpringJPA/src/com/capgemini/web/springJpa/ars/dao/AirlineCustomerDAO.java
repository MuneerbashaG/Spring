package com.capgemini.web.springJpa.ars.dao;


import java.util.List;

import com.capgemini.web.springJpa.ars.entities.Airport;
import com.capgemini.web.springJpa.ars.entities.BookingInformation;
import com.capgemini.web.springJpa.ars.entities.CustomerInformation;
import com.capgemini.web.springJpa.ars.entities.FlightInformation;
import com.capgemini.web.springJpa.ars.entities.LoginBean;
import com.capgemini.web.springJpa.ars.entities.SearchFlight;
import com.capgemini.web.springJpa.ars.exception.AirlineReservationSystemException;

public interface AirlineCustomerDAO {
	
	public void signUpCustomer(CustomerInformation customerInformation) throws AirlineReservationSystemException;
	
	public List<CustomerInformation> getUsers() throws AirlineReservationSystemException;
	
	public int addCustomerBooking(BookingInformation bookingInformation) throws AirlineReservationSystemException;
	
	public BookingInformation viewCustomerBooking(int bookingId,String username) throws AirlineReservationSystemException;
	
	public List<FlightInformation> viewFlightDetails(SearchFlight searchFlight) throws AirlineReservationSystemException;
	
	public void updateCustomerBooking(BookingInformation bookingInformation) throws AirlineReservationSystemException;
	
	public BookingInformation cancelCustomerBooking(int bookingId,String username) throws AirlineReservationSystemException;

	public List<Airport> getAllAirports() throws AirlineReservationSystemException;
	
	public FlightInformation viewSingleFlightDetail(int id) throws AirlineReservationSystemException;

	public boolean validateLogin(LoginBean login)throws AirlineReservationSystemException;
	
	public boolean searchCustomerExist(String userName)throws AirlineReservationSystemException;
	
	public boolean searchBookingExist(int bookingId,String username)throws AirlineReservationSystemException ;
}
