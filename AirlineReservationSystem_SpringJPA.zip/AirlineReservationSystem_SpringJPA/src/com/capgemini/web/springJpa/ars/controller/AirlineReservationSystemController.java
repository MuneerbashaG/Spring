package com.capgemini.web.springJpa.ars.controller;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.capgemini.web.springJpa.ars.entities.Airport;
import com.capgemini.web.springJpa.ars.entities.BookingInformation;
import com.capgemini.web.springJpa.ars.entities.CustomerInformation;
import com.capgemini.web.springJpa.ars.entities.FlightInformation;
import com.capgemini.web.springJpa.ars.entities.LoginBean;
import com.capgemini.web.springJpa.ars.entities.SearchFlight;
import com.capgemini.web.springJpa.ars.exception.AirlineReservationSystemException;
import com.capgemini.web.springJpa.ars.service.AirlineCustomerService;

@Controller
@SessionAttributes("sessionVar")
public class AirlineReservationSystemController {
	
	public int flightId;
	public Date departureDate;
	public Date arrivalDate;
	public String username;
	SimpleDateFormat simpleformatter=new SimpleDateFormat("dd-MM-yyyy");
	
	BookingInformation bookingInformation;
	
	@Autowired
	private AirlineCustomerService airlineCustomerService;

	public AirlineCustomerService getAirlineCustomerService() {
		return airlineCustomerService;
	}

	public void setAirlineCustomerService(
			AirlineCustomerService airlineCustomerService) {
		this.airlineCustomerService = airlineCustomerService;
	}
	
	
	
	/************************************************************************************
	* Module Name       : getMenuPage()
	* Input Parameters  : -
	* Return Type         : String
	* Author                 : Bodhiswatta and Charishma
	* Creation Date       : 26-Dec-2017
	*  Description          : Going to menu page
	 ************************************************************************************/
	@RequestMapping("/Menu.mvc")
	public String getMenuPage()
	{
		return "Menu";
	}
	
	
	
	
	/************************************************************************************
	* Module Name       : getBookingAFlightPage(model)
	* Input Parameters  : model
	* Return Type         : String
	* Author                 : Shruthi and Eniya
	* Creation Date       : 26-Dec-2017
	*  Description          : Going to Search Flight page with model attribute as airport list
	 ************************************************************************************/
	
	@RequestMapping("/BookAFlight.mvc")
	public String getBookingAFlightPage(Model model)
	{
		try {
			SearchFlight searchFlight = new SearchFlight();
			model.addAttribute("SearchFlight",searchFlight);
			
			List<Airport> airportLists = airlineCustomerService.getAllAirports();
			model.addAttribute("AirportLists",airportLists);
			return "SearchFlight";
		} 
		catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while processing the form. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while processing the form.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}

	}
	
	
	
	/************************************************************************************
	* Module Name       : customizeBinding(WebDataBinder binder)
	* Input Parameters  : WebDataBinder binder
	* Return Type         : void
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 27-Dec-2017
	*  Description          : method for bing date and changing the format
	 ************************************************************************************/
	//Init Binder for Search Flight
	@InitBinder("SearchFlight")
	public void customizeBinding(WebDataBinder binder)
	{
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		dateFormatter.setLenient(false);
		
		binder.registerCustomEditor(Date.class, "departureDate",
							new CustomDateEditor(dateFormatter, true) );
		
	}
	
	
	
	/************************************************************************************
	* Module Name       : processAddFlightBooking(@ModelAttribute("SearchFlight")@Valid SearchFlight searchFlight,BindingResult bindingResult,Model model)
	* Input Parameters  : @ModelAttribute("SearchFlight")@Valid SearchFlight searchFlight,BindingResult bindingResult,Model model
	* Return Type         : String
	* Author                 : Mudassir and Ruchir
	* Creation Date       : 28-Dec-2017
	*  Description          : To view the flight after searching from the database
	 ************************************************************************************/
	//after searching flight Viewing the flight
	@RequestMapping(value="/ProcessViewFlightBooking.mvc", method=RequestMethod.POST)
	public String processAddFlightBooking(@ModelAttribute("SearchFlight")@Valid SearchFlight searchFlight,BindingResult bindingResult,
			Model model)
	{
		if(bindingResult.hasErrors())
		{
			
			try {
				List<Airport> airportLists = airlineCustomerService.getAllAirports();
				model.addAttribute("AirportLists",airportLists);
				return "SearchFlight";
			} 
			catch(AirlineReservationSystemException e)
			{
				model.addAttribute("errMsg", "Something went wrong while processing the form. Reason: " + e.getMessage());
				return "ErrorPage";
			}
			catch (Exception e) {
				model.addAttribute("errMsg", "Something went wrong while processing the form.Contact the administrator. Reason: " + e.getMessage());
				return "ErrorPage";
			}
		
		}
		
		Date todaysdate = new Date();
		if(!todaysdate.before(searchFlight.getDepartureDate()))
		{
			try {
				List<Airport> airportLists = airlineCustomerService.getAllAirports();
				model.addAttribute("AirportLists",airportLists);
				model.addAttribute("wrongDate", "Cannot select previous date");
				return "SearchFlight";
			} 
			catch(AirlineReservationSystemException e)
			{
				model.addAttribute("errMsg", "Something went wrong while processing the form. Reason: " + e.getMessage());
				return "ErrorPage";
			}
			catch (Exception e) {
				model.addAttribute("errMsg", "Something went wrong while processing the form.Contact the administrator. Reason: " + e.getMessage());
				return "ErrorPage";
			}	
		}
		
		try {
			List<FlightInformation> flightInformationList = airlineCustomerService.viewFlightDetails(searchFlight);
			model.addAttribute("flightInformationList", flightInformationList);
			
			return "ViewFlights";
		} 
		catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while fetching the Flights Database. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while fetching the Flights.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}
	}
	
	/************************************************************************************
	* Module Name       : getClassType()
	* Input Parameters  : -
	* Return Type         : List<String>
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 26-Dec-2017
	*  Description          : Get all the class Type of flight
	 ************************************************************************************/
	
	//Flight class type
	public List<String> getClassType()
	{
		return Arrays.asList("First Class","Business Class");
	}

	/************************************************************************************
	* Module Name       : getFlightBookingPage(@RequestParam("flightId") int id, Model model)
	* Input Parameters  : @RequestParam("flightId") int id, Model model
	* Return Type         : String
	* Author                 : Mudassir and Ruchir
	* Creation Date       : 28-Dec-2017
	*  Description          : Go to Booking page for flight booking with previously filled flight information
	 ************************************************************************************/
	//Go to Booking page for flight booking with previously filled flight information
	@RequestMapping(value="/GetFlightBookingPage.mvc")
	public String getFlightBookingPage(@RequestParam("flightId") int id, Model model)
	{
		
		try
		{
			flightId  =id;
			
			if(!String.valueOf(id).isEmpty()) {
				
				FlightInformation flightInfo=airlineCustomerService.viewSingleFlightDetail(id);
				departureDate = flightInfo.getDepartureDate();
				arrivalDate = flightInfo.getArrivalDate();
				
				model.addAttribute("flightInfo", flightInfo);
				model.addAttribute("ClassType",getClassType());

				bookingInformation = new BookingInformation();
				
				bookingInformation.setFlightId(flightId);
				bookingInformation.setFlightNumber(flightInfo.getFlightNumber());
				bookingInformation.setAirline(flightInfo.getAirline());
				bookingInformation.setDepartureDate(departureDate);
				bookingInformation.setArrivalDate(arrivalDate);
				bookingInformation.setDepartureCity(flightInfo.getDepartureCity());
				bookingInformation.setArrivalCity(flightInfo.getArrivalCity());
				bookingInformation.setDepartureTime(flightInfo.getDepartureTime());
				bookingInformation.setArrivalTime(flightInfo.getArrivalTime());
				bookingInformation.setUserName(username);
				
				System.out.println("getflight:" + bookingInformation);
				
				model.addAttribute("bookFlight", bookingInformation);
				String ddate=simpleformatter.format(departureDate);
				String adate=simpleformatter.format(arrivalDate);
				model.addAttribute("ddate", ddate);
				model.addAttribute("adate", adate);
				
				return "BookFlight";
				
			}else {
				return "ErrorPage";
			}
			
			
		}
		catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while booking the flight. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while booking the flight.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		
	}
	
	
	
	/************************************************************************************
	* Module Name       : ProcessFlightBooking(@ModelAttribute("bookFlight") BookingInformation bookingInformation, BindingResult bindingResult, Model model)
	* Input Parameters  : @ModelAttribute("bookFlight") BookingInformation bookingInformation, BindingResult bindingResult, Model model
	* Return Type         : String
	* Author                 : Mudassir and Ruchir
	* Creation Date       : 29-Dec-2017
	*  Description          : After submit of booking page to process and insert into database
	 ************************************************************************************/
	//after submit of booking page to process and insert into database
	@RequestMapping(value="/ProcessFlightBookingForm.mvc",method=RequestMethod.POST)
	public String ProcessFlightBooking(@ModelAttribute("bookFlight") BookingInformation bookingInformation, BindingResult bindingResult, Model model)
	{
		try {
			boolean flag=true;
			
			if(bookingInformation.getCustomerName() == null || !bookingInformation.getCustomerName().matches("[A-Za-z ]+"))
			{
				flag=false;
				model.addAttribute("msg1", " \tPlease Enter Alphabets");
			}

			if(bookingInformation.getCustomerEmail() == null || !bookingInformation.getCustomerEmail().matches("[a-z0-9]+@[a-z]+.[a-z]{2,3}"))
			{
				flag=false;
				model.addAttribute("msg2", "  \tPlease enter in proper format. example:- abc@xyz.com");
			}

			if(bookingInformation.getCustomerPhoneNumber() == null || !bookingInformation.getCustomerPhoneNumber().matches("[0-9]{10}"))
			{
				flag=false;
				model.addAttribute("msg3", "  	\tNumber should consists 10 digits");
			}

			if(bookingInformation.getNoOfPassangers() == 0)
			{
				flag=false;
				model.addAttribute("msg4", "  	\tPlease select atleast 1 seat to book");
			}

			if(bookingInformation.getClassType() == null)
			{
				flag=false;
				model.addAttribute("msg5", "  	\tSelect any class");
			}

			if(bookingInformation.getCreditCardNumber() == null || !bookingInformation.getCreditCardNumber().matches("[0-9]{16}"))
			{
				flag=false;
				model.addAttribute("msg6", "  \tCredit Card number must have 16 digits");
			}
			if(!flag)
			{
				FlightInformation flightInfo=airlineCustomerService.viewSingleFlightDetail(flightId);
				departureDate = flightInfo.getDepartureDate();
				arrivalDate = flightInfo.getArrivalDate();

				model.addAttribute("flightInfo", flightInfo);
				model.addAttribute("ClassType",getClassType());

				

				bookingInformation.setFlightId(flightId);
				bookingInformation.setFlightNumber(flightInfo.getFlightNumber());
				bookingInformation.setAirline(flightInfo.getAirline());
				bookingInformation.setDepartureDate(departureDate);
				bookingInformation.setArrivalDate(arrivalDate);
				bookingInformation.setDepartureCity(flightInfo.getDepartureCity());
				bookingInformation.setArrivalCity(flightInfo.getArrivalCity());
				bookingInformation.setDepartureTime(flightInfo.getDepartureTime());
				bookingInformation.setArrivalTime(flightInfo.getArrivalTime());
				bookingInformation.setUserName(username);

				System.out.println("Process flight in if:" + bookingInformation);

				model.addAttribute("bookFlight", bookingInformation);
				String ddate=simpleformatter.format(bookingInformation.getDepartureDate());
				String adate=simpleformatter.format(bookingInformation.getArrivalDate());
				model.addAttribute("ddate", ddate);
				model.addAttribute("adate", adate);
				return "BookFlight";
			}
			
			bookingInformation.setFlightId(flightId);
			bookingInformation.setDepartureDate(departureDate);
			bookingInformation.setArrivalDate(arrivalDate);
			bookingInformation.setUserName(username);
			
			System.out.println("Process flight out if:" + bookingInformation);
			
			int bookingId = airlineCustomerService.addCustomerBooking(bookingInformation);
			model.addAttribute("bookingId",bookingId);
			
			
			return "BookFlight";
		} catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while adding the booking Information. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while adding the booking Information.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}
	}
	
	 /************************************************************************************
		* Module Name       : getLoginPage(Model model)
		* Input Parameters  : model
		* Return Type         : String
		* Author                 : Shruthi and Eniya
		* Creation Date       : 27-Dec-2017
		*  Description          : Login
		 ************************************************************************************/
	//Login and Signup
	@RequestMapping("/Login.mvc")
	public String getLoginPage(Model model)
	{
		model.addAttribute("login", new LoginBean());
		return "Login";
	}
	
	
	 /************************************************************************************
	* Module Name       : processLogin(@ModelAttribute("login") @Valid LoginBean login,BindingResult binding,Model model)
	* Input Parameters  : @ModelAttribute("login") @Valid LoginBean login,BindingResult binding,Model model
	* Return Type         : String
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 26-Dec-2017
	*  Description          : Login checking and creating session
	 ************************************************************************************/
	
	//Login checking and creating session
	@RequestMapping("/processLogin.mvc")
	public String processLogin(
			@ModelAttribute("login") @Valid LoginBean login,
			BindingResult binding,
			Model model)
	{
		try 
		{
		
			if(binding.hasErrors())
			{
				return "Login";
			}
			
			if(airlineCustomerService.searchCustomerExist(login.getUsername()))
			{
				
				if(airlineCustomerService.validateLogin(login))
				{
					username = login.getUsername();
					model.addAttribute("sessionVar", login.getUsername() );
					return "Menu";
				}	
			}
			model.addAttribute("errMsg", "Invalid Username/Password");			
			model.addAttribute("login",login);
			return "Login";
		} 
		catch (AirlineReservationSystemException e) 
		{
			model.addAttribute("errMsg","Something Went wrong while Trying to Login. Reason: "+e.getMessage());
			return "ErrorPage";
		}
		
		
	}
	
	/************************************************************************************
	* Module Name       : getSignUpForm(Model model)
	* Input Parameters  : Model model
	* Return Type         : String
	* Author                 : Eniya Murali and Bodhiswatta
	* Creation Date       : 26-Dec-2017
	*  Description          : go to signup page
	 ************************************************************************************/
	//go to signup page
	@RequestMapping("/SignUp.mvc")
	public String getSignUpForm(Model model)
	{
		model.addAttribute("signup",new CustomerInformation());
		return "SignUp";
	}
	
	 /************************************************************************************
		* Module Name       : processSignUp(@ModelAttribute("signup") @Valid CustomerInformation signup,BindingResult binding, Model model)
		* Input Parameters  : @ModelAttribute("signup") @Valid CustomerInformation signup,BindingResult binding, Model model
		* Return Type         : String
		* Author                 : Eniya Murali and Bodhiswatta
		* Creation Date       : 26-Dec-2017
		*  Description          : process signup page and store the customer details in database
		 ************************************************************************************/
	//process signup page and store the customer details in database
	@RequestMapping("/processSignUp.mvc")
	public String processSignUp(@ModelAttribute("signup") @Valid CustomerInformation signup,
			BindingResult binding, Model model)
	{
		if(binding.hasErrors())
		{
			return "SignUp";
		}
		
		if (!signup.getConfirmPassword().equals(signup.getPassword())) 
		{		
			model.addAttribute("errMsg1", "Password does not match!!!");
			return "SignUp";
		}
		
		try {
				
			if(airlineCustomerService.searchCustomerExist(signup.getUserName()))
			{
				model.addAttribute("errMsg", "Username Already Exist!!");
				return "SignUp";
			}
			
			
			airlineCustomerService.signUpCustomer(signup);
			model.addAttribute("login",new LoginBean());
			model.addAttribute("loginMsg", "Registration Successful.");
			
			return "Login";
			
		} catch (AirlineReservationSystemException e) 
		{
			model.addAttribute("errMsg",e.getMessage());			
			return "ErrorPage";
		}
		
	}
	
		 /************************************************************************************
			* Module Name       : viewCustomerBooking(Model model)
			* Input Parameters  : Model model
			* Return Type         : String
			* Author                 :Shruthi and Eniya
			* Creation Date       : 26-Dec-2017
			*  Description          : Go to view page
			 ************************************************************************************/
	//Go to view page
	@RequestMapping("/ViewBookingDetails.mvc")
	public String viewCustomerBooking(Model model)
	{
		BookingInformation bookingInformation = new BookingInformation();
		
		model.addAttribute("bookingInfo",bookingInformation);
		
		return "ViewFlightBooking";
	}
	
			 /************************************************************************************
				* Module Name       : processViewBookingIformation(@ModelAttribute("bookingInfo") BookingInformation bookingInformation, BindingResult bindingResult, Model model)
				* Input Parameters  : @ModelAttribute("bookingInfo") BookingInformation bookingInformation, BindingResult bindingResult, Model model
				* Return Type         : String
				* Author                 : Eniya Murali and Bodhiswatta
				* Creation Date       : 27-Dec-2017
				*  Description          : Process view booking information
				 ************************************************************************************/
	//Process view booking information
	@RequestMapping(value="/ProcessViewCustomerBooking.mvc", method=RequestMethod.POST)
	public String processViewBookingIformation(@ModelAttribute("bookingInfo") BookingInformation bookingInformation, BindingResult bindingResult, Model model)
	{
		
		try {
				
				if(airlineCustomerService.searchBookingExist(bookingInformation.getBookingId(),username)!=true)
				{
					model.addAttribute("errMsg", "There are no bookings available under this booking Id");
					return "ErrorPage";
					
				}else
				{
					bookingInformation = airlineCustomerService.viewCustomerBooking(bookingInformation.getBookingId(),username);
					model.addAttribute("bookingInfo",bookingInformation);
					
					String ddate=simpleformatter.format(bookingInformation.getDepartureDate());
					String adate=simpleformatter.format(bookingInformation.getArrivalDate());
					model.addAttribute("ddate", ddate);
					model.addAttribute("adate", adate);
					
					return "ViewFlightBooking";
				}
		} catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while viewing the booking Information. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while viewing the booking Information.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		
	}
	
				 /************************************************************************************
					* Module Name       : viewUpdatePage(Model model)
					* Input Parameters  : (Model model
					* Return Type         : String
					* Author                 : Shruthi and Eniya
					* Creation Date       : 27-Dec-2017
					*  Description          : Go to update Page
					 ************************************************************************************/
	//Go to update Page
	@RequestMapping("/UpdateBookingDetails.mvc")
	public String viewUpdatePage(Model model)
	{	
		return "UpdateBooking";
	}
	
					 /************************************************************************************
						* Module Name       : processFetchBookingForUpdate(Model model, @RequestParam("id") int bookingid)
						* Input Parameters  : Model model, @RequestParam("id") int bookingid
						* Return Type         : String
						* Author                 : Eniya Murali and Bodhiswatta
						* Creation Date       : 27-Dec-2017
						*  Description          : process to fetch booking details
						 ************************************************************************************/
	//process to fetch booking details
	@RequestMapping("/ProcessFetchBookingForUpdate.mvc")
	public String processFetchBookingForUpdate(Model model, @RequestParam("id") int bookingid)
	{
			try {
			
				
				
			BookingInformation bookingInformation = airlineCustomerService.viewCustomerBooking(bookingid,username);
			
			departureDate = bookingInformation.getDepartureDate();
			arrivalDate  = bookingInformation.getArrivalDate();
			
			model.addAttribute("bookingInfo", bookingInformation);
			String ddate=simpleformatter.format(bookingInformation.getDepartureDate());
			String adate=simpleformatter.format(bookingInformation.getArrivalDate());
			model.addAttribute("ddate", ddate);
			model.addAttribute("adate", adate);
			return "UpdateBooking";
			
		} catch(AirlineReservationSystemException e)
		{
			model.addAttribute("errMsg", "Something went wrong while fetching the booking Information. Reason: " + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			model.addAttribute("errMsg", "Something went wrong while fetching the booking Information.Contact the administrator. Reason: " + e.getMessage());
			return "ErrorPage";
		}
	}
	/************************************************************************************
	* Module Name       : processUpdateBookingDetails(@ModelAttribute("bookingInfo") BookingInformation bookingInformation,BindingResult bindingResult,Model model)
	* Input Parameters  : @ModelAttribute("bookingInfo") BookingInformation bookingInformation,BindingResult bindingResult,Model model
	* Return Type         : String
	* Author                 : Mudassir and Ruchir
	* Creation Date       : 28-Dec-2017
	*  Description          : Update the booking details to the database
	 ************************************************************************************/
	@RequestMapping("/ProcessUpdateBookingDetails.mvc")
	public String processUpdateBookingDetails(
			@ModelAttribute("bookingInfo") BookingInformation bookingInformation,
			BindingResult bindingResult,
			Model model
			)
		{
		
		
			try {
				
				boolean flag=true;
				
				if(bookingInformation.getCustomerName() == null || !bookingInformation.getCustomerName().matches("[A-Za-z ]+"))
				{
					flag=false;
					model.addAttribute("msg1", " \tPlease Enter Alphabets");
				}

				if(bookingInformation.getCustomerEmail() == null || !bookingInformation.getCustomerEmail().matches("[a-z0-9]+@[a-z]+.[a-z]{2,3}"))
				{
					flag=false;
					model.addAttribute("msg2", "  \tPlease enter in proper format. example:- abc@xyz.com");
				}

				if(bookingInformation.getCustomerPhoneNumber() == null || !bookingInformation.getCustomerPhoneNumber().matches("[0-9]{10}"))
				{
					flag=false;
					model.addAttribute("msg3", "  	\tNumber should consists 10 digits");
				}
				if(!flag)
				{
					bookingInformation = airlineCustomerService.viewCustomerBooking(bookingInformation.getBookingId(),username);
					
					departureDate = bookingInformation.getDepartureDate();
					arrivalDate  = bookingInformation.getArrivalDate();
					String ddate=simpleformatter.format(bookingInformation.getDepartureDate());
					String adate=simpleformatter.format(bookingInformation.getArrivalDate());
					model.addAttribute("ddate", ddate);
					model.addAttribute("adate", adate);
					
					
					model.addAttribute("bookingInfo", bookingInformation);
					
					return "UpdateBooking";
				}
				
				bookingInformation.setDepartureDate(departureDate);
				bookingInformation.setArrivalDate(arrivalDate);
				bookingInformation.setUserName(username);
				System.out.println("Update: " + bookingInformation);
				
				airlineCustomerService.updateCustomerBooking(bookingInformation);
				model.addAttribute("bookingInfo", null);
				model.addAttribute("message", "Booking Details Updated Sucessfully for ID: " + bookingInformation.getBookingId());
				
				return "UpdateBooking";
				
			} catch(AirlineReservationSystemException e)
			{
				model.addAttribute("errMsg", "Something went wrong while fetching the booking Information. Reason: " + e.getMessage());
				return "ErrorPage";
			}
			
			catch (Exception e) {
				model.addAttribute("errMsg", "Something went wrong while fetching the booking Information.Contact the administrator. Reason: " + e.getMessage());
				return "ErrorPage";
			}
		
		}
	 
	 /************************************************************************************
		* Module Name       : getCancelBookingPage()
		* Input Parameters  : -
		* Return Type         : String
		* Author                 : Eniya Murali and Bodhiswatta
		* Creation Date       : 29-Dec-2017
		*  Description          : Cancel booking
		 ************************************************************************************/
	//Cancel Booking
	
		@RequestMapping("/getCancel.mvc")
		public String getCancelBookingPage()
		{
			return "CancelBooking";
		}
		
		@RequestMapping("/ProcessCancelBooking.mvc")
		public String processCancelBooking(@RequestParam("id") int bookingId,Model model)
		{
			
			try {
				
				if(airlineCustomerService.searchBookingExist(bookingId,username)!=true)
				{
					model.addAttribute("errMsg", "There are no bookings available under this booking Id");
					return "ErrorPage";	
					
				}else
				{
					BookingInformation bookingInformation=airlineCustomerService.cancelCustomerBooking(bookingId,username);
					model.addAttribute("bookingInformation",bookingInformation);
					model.addAttribute("msg","The above booking have been cancelled successfully");
					return "CancelBooking";
				}
				
			} catch(AirlineReservationSystemException e)
			{
				model.addAttribute("errMsg", "Something went wrong while Cancelling the booking. "+ e.getMessage());
				return "ErrorPage";
			}
			catch (Exception e) {
				model.addAttribute("errMsg", "Something went wrong while Cancelling the booking.Contact the administrator. Reason: " + e.getMessage());
				return "ErrorPage";
			}
			
		}
		/************************************************************************************
		* Module Name       : signOut(Model model)
		* Input Parameters  : Model model
		* Return Type         : String
		* Author                 : Bodhiswatta and Charishma
		* Creation Date       : 27-Dec-2017
		*  Description          : for logout and closing the session
		 ************************************************************************************/
		//for logout and closing the session
		@RequestMapping("/Logout.mvc")
		 public String signOut(Model model)
		{  
			model.addAttribute("sessionVar","");
			model.addAttribute("login",new LoginBean());
			return "Login"; 
	}
}
