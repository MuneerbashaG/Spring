package com.capgemini.web.springJpa.ars.entities;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Airport {
	@Id
	private String airportAbbreviation;
	private String airportName;
	private String locationCity;
	private String State;
	private BigInteger zipCode;
	public Airport() {
		super();
	}
	public Airport(String airportAbbreviation, String airportName,
			String locationCity, String state, BigInteger zipCode) {
		super();
		this.airportAbbreviation = airportAbbreviation;
		this.airportName = airportName;
		this.locationCity = locationCity;
		State = state;
		this.zipCode = zipCode;
	}
	public String getAirportAbbreviation() {
		return airportAbbreviation;
	}
	public void setAirportAbbreviation(String airportAbbreviation) {
		this.airportAbbreviation = airportAbbreviation;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getLocationCity() {
		return locationCity;
	}
	public void setLocationCity(String locationCity) {
		this.locationCity = locationCity;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public BigInteger getZipCode() {
		return zipCode;
	}
	public void setZipCode(BigInteger zipCode) {
		this.zipCode = zipCode;
	}
	@Override
	public String toString() {
		return "Airport [airportAbbreviation=" + airportAbbreviation
				+ ", airportName=" + airportName + ", locationCity="
				+ locationCity + ", State=" + State + ", zipCode=" + zipCode
				+ "]";
	}
	
	
}
